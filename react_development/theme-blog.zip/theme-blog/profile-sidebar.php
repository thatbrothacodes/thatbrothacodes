<?php if ( is_active_sidebar( 'profile-sidebar' ) ) : ?>
    <?php dynamic_sidebar( 'profile-sidebar' ); ?>
<?php endif; ?>
